﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    /// <summary>
    /// Gets or sets an array of objects in which you can specify any attachments you want to include.
    /// </summary>
    public class Attachment
    {
        /// <summary>
        /// Gets or sets the Base64 encoded content of the attachment.
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        ///  Gets or sets the mime type of the content you are attaching. For example, application/pdf or image/jpeg.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the filename of the attachment.
        /// </summary>
        public string Filename { get; set; }
    }
}
