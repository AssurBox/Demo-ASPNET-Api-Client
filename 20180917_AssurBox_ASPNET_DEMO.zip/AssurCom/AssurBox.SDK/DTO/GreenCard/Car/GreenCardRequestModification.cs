﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO.GreenCard.Car
{
    /// <summary>
    /// Represents a modification of a green card request
    /// </summary>
    public class GreenCardRequestModification
    {
        /// <summary>
        /// Date of request creation
        /// </summary>
        public DateTime RequestDateUTC { get; set; }

        /// <summary>
        /// The unique identifier for the whole process of the green card request
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// The licence plate
        /// </summary>
        /// <remarks>Mandatory</remarks>
        public string LicencePlate { get; set; }
        /// <summary>
        /// The Vehicle Identification Number
        /// </summary>
        /// <remarks>Mandatory</remarks>
        public string VIN { get; set; }

        /// <summary>
        /// An enventual communication for the insurance
        /// </summary>
        public string Communication { get; set; }
    }
}
