﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// Represents a person in AssurBox
    /// </summary>
    public class Person
    {
        /// <summary>
        /// LastName of the <see cref="Person"/>
        /// </summary>
        /// <example>
        /// Beauvois
        /// </example>
        public string LastName { get; set; }
        /// <summary>
        /// FirstName of the <see cref="Person"/>
        /// </summary>
        /// <example>
        /// Samuel
        /// </example>
        public string FirstName { get; set; }
        /// <summary>
        /// BirthDate of the <see cref="Person"/>
        /// </summary>
        public DateTime? BirthDate { get; set; }
        /// <summary>
        /// Email of the <see cref="Person"/>
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Phone of the <see cref="Person"/>
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// Fax of the <see cref="Person"/>
        /// </summary>
        public string Fax { get; set; }
        /// <summary>
        /// Gsm of the <see cref="Person"/>
        /// </summary>
        public string Gsm { get; set; }
        /// <summary>
        /// DrivingLicenseNumber of the <see cref="Person"/>
        /// </summary>
        public string DrivingLicenseNumber { get; set; }
        /// <summary>
        /// Address information of the <see cref="Person"/>
        /// </summary>
        public Address Address { get; set; }
    }
}
