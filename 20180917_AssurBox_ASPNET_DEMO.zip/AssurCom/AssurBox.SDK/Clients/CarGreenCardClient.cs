﻿using AssurBox.SDK.DTO.GreenCard.Car;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssurBox.SDK.Clients
{
    public class CarGreenCardClient : AssurBoxClient
    {
        public CarGreenCardClient(AssurBoxClientOptions options) : base(options)
        {
        }

        public CarGreenCardClient(string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public CarGreenCardClient(HttpClient httpClient, string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(httpClient, apiKey, host, requestHeaders, version, urlPath)
        {
        }

        internal CarGreenCardClient(HttpClient httpClient, AssurBoxClientOptions options) : base(httpClient, options)
        {
        }

        /***** GET *********************/

        /// <summary>
        /// Gets a lst of insurances issuing green cards
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<IEnumerable<DTO.Organization>> GetInsurancesGreenCardsIssuers(CancellationToken cancellationToken = default(CancellationToken))
        {

            var response = await client.GetAsync($"/api/{Version}/GreenCard/Car/Insurances");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<IEnumerable<DTO.Organization>>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        /// <summary>
        /// Gets a list of green card requests for car for the caller
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns>List of green card requests for car</returns>
        public async Task<IEnumerable<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestInfoSummary>> GetRequests(CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.GetAsync($"/api/{Version}/GreenCard/Car/Requests", cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<IEnumerable<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestInfoSummary>>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        /// <summary>
        /// Gets a specific green card request for car
        /// </summary>
        /// <param name="correlationId"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestInfo> GetRequest(Guid correlationId, CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.GetAsync($"/api/{Version}/GreenCard/Car/Requests/{correlationId}", cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestInfo>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestInfo> GetRequest(string correlationId, CancellationToken cancellationToken = default(CancellationToken))
        {
            return await GetRequest(new Guid(correlationId), cancellationToken);
        }

        /// <summary>
        /// Gets only the response for one green card request. (not the full request object)
        /// </summary>
        /// <param name="correlationId"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestResponse> GetResponse(Guid correlationId, CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.GetAsync($"/api/{Version}/GreenCard/Car/Requests/{correlationId}/Responses", cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestResponse>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }
        public async Task<AssurBox.SDK.DTO.GreenCard.Car.GreenCardRequestResponse> GetResponse(string correlationId, CancellationToken cancellationToken = default(CancellationToken))
        {
            return await GetResponse(new Guid(correlationId), cancellationToken);
        }

        public async Task<AssurBox.SDK.Attachment> GetDocumentSNCA(Guid correlationId, CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.GetAsync($"/api/{Version}/GreenCard/Car/Requests/{correlationId}/DocumentsSNCA", cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<AssurBox.SDK.Attachment>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }
        public async Task<AssurBox.SDK.Attachment> GetDocumentSNCA(string correlationId, CancellationToken cancellationToken = default(CancellationToken))
        {
            return await GetDocumentSNCA(new Guid(correlationId), cancellationToken);
        }


        /*POST*/


        public async Task<AssurBox.SDK.ApiResponse> NewRequest(GreenCardRequestInitialization request, CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.PostAsJsonAsync($"/api/{Version}/GreenCard/Car/Requests", request, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsApiResponseAsync();
            }
            else
            {
                var error = await response.Content.ReadAsApiErrorAsync();
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<AssurBox.SDK.ApiResponse> ChangeRequest(GreenCardRequestModification request, CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.PutAsJsonAsync($"/api/{Version}/GreenCard/Car/Requests", request, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsApiResponseAsync();
            }
            else
            {
                var error = await response.Content.ReadAsApiErrorAsync();
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<AssurBox.SDK.ApiResponse> CancelRequest(GreenCardRequestCancellation request, CancellationToken cancellationToken = default(CancellationToken))
        {
            string requesturi = $"/api/{Version}/GreenCard/Car/Requests/?CorrelationId={request.CorrelationId}&Communication={request.Communication}&RequestDateUTC={request.RequestDateUTC}";

            var response = await client.DeleteAsync(requesturi, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsApiResponseAsync();
            }
            else
            {
                var error = await response.Content.ReadAsApiErrorAsync();
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<AssurBox.SDK.ApiResponse> SendResponse(GreenCardRequestResponse greenCardResponse, CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.PostAsJsonAsync($"/api/{Version}/GreenCard/Car/Requests/{greenCardResponse.CorrelationId}/Responses", greenCardResponse, cancellationToken);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsApiResponseAsync();
            }
            else
            {
                var error = await response.Content.ReadAsApiErrorAsync();
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase + " " + error.ToString());
            }
        }


    }
}
