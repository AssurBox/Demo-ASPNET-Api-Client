﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    /// <summary>
    /// Extensions for HttpContent deserialization
    /// </summary>
    public static class HttpContentExtensions
    {
        /// <summary>
        /// Deserialize content as <see cref="ApiResponse"/>
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        public static Task<ApiResponse> ReadAsApiResponseAsync(this HttpContent content)
        {
            return content.ReadAsAsync<ApiResponse>();
        }

        /// <summary>
        /// Deserialize content as <see cref="ApiError"/>
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        public static Task<ApiError> ReadAsApiErrorAsync(this HttpContent content)
        {
            return content.ReadAsAsync<ApiError>();
        }
    }
}
