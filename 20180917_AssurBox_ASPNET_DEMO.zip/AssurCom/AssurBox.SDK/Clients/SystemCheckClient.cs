﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssurBox.SDK.Clients
{
    public class SystemCheckClient : AssurBoxClient
    {
        public SystemCheckClient(AssurBoxClientOptions options) : base(options)
        {
        }

        public SystemCheckClient(string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public SystemCheckClient(HttpClient httpClient, string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(httpClient, apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public SystemCheckClient(HttpClient httpClient, AssurBoxClientOptions options) : base(httpClient, options)
        {
        }


        /// <summary>
        /// Sends a test message to the server to check if it's answering
        /// </summary>
        /// <param name="input"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<string> Echo(string input, CancellationToken cancellationToken = default(CancellationToken))
        {

            var response = await client.GetAsync($"/api/{Version}/echo?id={input}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<string>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }
    }
}
