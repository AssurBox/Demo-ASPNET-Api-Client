﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{

    [Serializable]
    public class AssurBoxException : Exception
    {
        /// <summary>
        /// Gets or sets the error code (HTTP status code)
        /// </summary>
        /// <value>The error code (HTTP status code).</value>
        public int ErrorCode { get; set; }

        /// <summary>
        /// Details of the error
        /// </summary>
        public ApiError ErrorDetail { get; set; }

        public AssurBoxException() { }
        public AssurBoxException(string message) : base(message) { }

        public AssurBoxException(string message, Exception inner) : base(message, inner) { }
        protected AssurBoxException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }


        /// <summary>
        /// Initializes a new instance of the <see cref="AssurBoxException"/> class.
        /// </summary>
        /// <param name="errorCode">HTTP status code.</param>
        /// <param name="message">Error message.</param>
        public AssurBoxException(int errorCode, string message) : this(message)
        {
            this.ErrorCode = errorCode;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AssurBoxException"/> class.
        /// </summary>
        /// <param name="errorCode">HTTP status code.</param>
        /// <param name="message">Error message.</param>
        public AssurBoxException(ApiError error, int errorCode, string message) : this(errorCode, message)
        {
            this.ErrorDetail = error;
        }
    }
}
