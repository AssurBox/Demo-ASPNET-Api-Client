﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    ///// <summary>
    ///// 
    ///// </summary>
    //public interface IApiMessage
    //{
    //}

    /// <summary>
    /// Base class for api messages
    /// </summary>
    public class ApiMessage
    {
        /// <summary>
        /// Location of the ressource
        /// <see href="https://github.com/Microsoft/api-guidelines/blob/master/Guidelines.md"/>
        /// </summary>
        public string Location { get; set; }

        /// <summary>
        /// Identifier for this specific message
        /// </summary>
        public Guid MessageId { get; set; }
    }
}
