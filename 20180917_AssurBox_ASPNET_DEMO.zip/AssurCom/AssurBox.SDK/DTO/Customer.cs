﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// Represents a customer
    /// </summary>
    public class Customer
    {
        /// <summary>
        /// Customer info if the customer is a Phisical person
        /// </summary>
        /// <example>
        /// Samuel Beauvois
        /// </example>
        public Person Person { get; set; }

        /// <summary>
        /// Customer info if te customer is a company (moral person)
        /// </summary>
        /// <example>
        /// C-Services SA
        /// </example>
        public Company Company { get; set; }

        /// <summary>
        /// Reference of the customer in the sender system 
        /// </summary>
        /// <remarks>
        /// Reference in the garage's DMS system in case we know it (sent from DMS)
        /// </remarks>
        /// <example>
        /// CUST000222
        /// </example>
        public string PartnerOrganizationReference { get; set; }

        /// <summary>
        /// Reference of the customer in the recipient system 
        /// </summary>
        /// <remarks>
        /// Reference in the insurer's system in case we know it (retrieved via api)
        /// </remarks>
        /// <example>
        /// 110000214
        /// </example>
        public string InsuranceOrganizationReference { get; set; }
    }
}
