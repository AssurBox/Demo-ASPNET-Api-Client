﻿using AssurBox.SDK.DTO;
using AssurBox.SDK.DTO.GreenCard.Car;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.SampleData
{
    /// <summary>
    /// These data are fore test purpose
    /// </summary>
    public class DevelopperStartup_DataForTests
    {
        /// <summary>
        /// Get sample data for a garage request
        /// </summary>
        /// <returns></returns>
        public static GreenCardRequestInitialization GetSampleData_Garage()
        {
            GreenCardRequestInitialization request = new GreenCardRequestInitialization
            {
                RequestDateUTC = DateTime.UtcNow,
                EffectiveDate = DateTime.Today,
                Communication = "Sample Data From AssurBox SDK - Garage",
                RecipientInsurer = new DTO.Organization
                {
                    Identifier = 51,
                    Name = "Assurance Lambda"
                },
                Customer = new DTO.Customer
                {
                    Person = new DTO.Person
                    {
                        LastName = "Haddock",
                        FirstName = "Archibald",
                        BirthDate = new DateTime(1942, 2, 12),
                        Email = "archibald.haddock@assurbox.net",
                        Gsm = "+352621255208",
                        Address = new Address
                        {
                            Street = "Rue du chateau",
                            Number = "1",
                            ZipOrPostcode = "1100",
                            City = "Moulinsart",
                            Country = "Luxembourg",
                        }
                    }
                },
                CarDetails = new Car
                {
                    LicencePlate = "BE4987",
                    VIN = "WDDHF5GB3BA376636",
                    Make = "volkswagen",
                    Model = "Passat",
                    DateOfVehicleRegistration = new DateTime(2017, 01, 11),
                    Fuel = FuelTypes.Diesel
                }
            };


            return request;
        }

        /// <summary>
        /// Get sample data for a partner (ord)
        /// </summary>
        /// <returns></returns>
        public static GreenCardRequestInitialization GetSampleData_ORD()
        {
            GreenCardRequestInitialization request = GetSampleData_Garage();
            request.Communication = "Sample Data From AssurBox SDK - ORD";
            request.OwnerIfDifferentFromCustomer = new Company
            {
                Name = "ALD Automotive",
                LegalAddress = new Address
                {
                    Street= "Route d'Arlon",
                    Number="270",
                    ZipOrPostcode="8010",
                    City="Strassen",
                    Country="Luxembourg"

                },
                Representative = new Person
                {
                    
                },
                VAT = "LU12977109"
            };

            return request;
        }
    }
}
