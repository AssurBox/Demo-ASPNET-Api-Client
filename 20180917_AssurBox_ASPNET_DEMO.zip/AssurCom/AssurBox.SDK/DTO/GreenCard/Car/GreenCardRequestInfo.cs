﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO.GreenCard.Car
{
    /// <summary>
    /// This class represents the part that should be loaded when using GET for a list of requests
    /// </summary>
    public class GreenCardRequestInfoSummary : ApiMessage
    {
        /// <summary>
        /// The identifier you can use to retrieve the full object
        /// </summary>
        public Guid CorrelationId { get; set; }

        // todo : statuses

        public string LicencePlate { get; set; }

        public DateTime RequestDate { get; set; }

        public string CustomerName { get; set; }
        /// <summary>
        /// Name of the insurer to whom the request was made
        /// </summary>
        public string InsuranceName { get; set; }

        /// <summary>
        /// Name of the organization that sent the request
        /// </summary>
        public string SenderOrganizationName { get; set; }
        
        /// <summary>
        /// This flag indicate whether or not a response is available
        /// </summary>
        public bool HasResponse { get; set; }


        //--------------------------------------
    }
    /// <summary>
    /// This class represents the loaded information about a request
    /// </summary>
    public class GreenCardRequestInfo : GreenCardRequestInfoSummary
    {
        public string ResponseCommunication { get; set; }

        public List<Attachment> Attachments { get; set; }
    }
}
