﻿using AssurBox.SDK.Reliability;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    /// <summary>
    /// A HTTP client wrapper for interacting with AssurBox's API
    /// </summary>
    public class AssurBoxClient : IDisposable
    {
        private readonly AssurBoxClientOptions options = new AssurBoxClientOptions();

        /// <summary>
        /// Gets or sets the path to the API resource.
        /// </summary>
        public string UrlPath { get; set; }

        /// <summary>
        /// Gets or sets the API version.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the request media type.
        /// </summary>
        public string MediaType { get; set; }

        /// <summary>
        /// The HttpClient instance to use for all calls from this SendGridClient instance.
        /// </summary>
        protected HttpClient client;

        /// <summary>
        /// Initializes a new instance of the <see cref="AssurBoxClient"/> class.
        /// </summary>
        /// <param name="options">A <see cref="AssurBoxClientOptions"/> instance that defines the configuration settings to use with the client </param>
        /// <returns>Interface to the AssurBox REST API</returns>
        public AssurBoxClient(AssurBoxClientOptions options)
            : this(null, options)
        {
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="AssurBoxClient"/> class.
        /// </summary>
        /// <param name="httpClient">An optional http client which may me injected in order to facilitate testing.</param>
        /// <param name="options">A <see cref="AssurBoxClientOptions"/> instance that defines the configuration settings to use with the client </param>
        /// <returns>Interface to the AssurBox REST API</returns>
        public AssurBoxClient(HttpClient httpClient, AssurBoxClientOptions options)
        {
            if (options == null)
            {
                throw new ArgumentNullException(nameof(options));
            }

            this.options = options;
            client = (httpClient == null) ? CreateHttpClientWithRetryHandler() : httpClient;

            InitiateClient(options.ApiKey, options.Host, options.RequestHeaders, options.Version, options.UrlPath);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AssurBoxClient"/> class.
        /// </summary>
        /// <param name="httpClient">An optional http client which may me injected in order to facilitate testing.</param>
        /// <param name="apiKey">Your SendGrid API key.</param>
        /// <param name="host">Base url (e.g. https://api.sendgrid.com)</param>
        /// <param name="requestHeaders">A dictionary of request headers</param>
        /// <param name="version">API version, override AddVersion to customize</param>
        /// <param name="urlPath">Path to endpoint (e.g. /path/to/endpoint)</param>
        /// <returns>Interface to the SendGrid REST API</returns>
        public AssurBoxClient(HttpClient httpClient, string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null)
            : this(httpClient, new AssurBoxClientOptions() { ApiKey = apiKey, Host = host, RequestHeaders = requestHeaders, Version = version, UrlPath = urlPath })
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AssurBoxClient"/> class.
        /// </summary>
        /// <param name="apiKey">Your SendGrid API key.</param>
        /// <param name="host">Base url (e.g. https://api.sendgrid.com)</param>
        /// <param name="requestHeaders">A dictionary of request headers</param>
        /// <param name="version">API version, override AddVersion to customize</param>
        /// <param name="urlPath">Path to endpoint (e.g. /path/to/endpoint)</param>
        /// <returns>Interface to the SendGrid REST API</returns>
        public AssurBoxClient(string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null)
            : this(httpClient: null, apiKey: apiKey, host: host, requestHeaders: requestHeaders, version: version, urlPath: urlPath)
        {
        }

        private HttpClient CreateHttpClientWithRetryHandler()
        {
            return new HttpClient(new RetryDelegatingHandler(options.ReliabilitySettings));
        }

        /// <summary>
        /// Common method to initiate internal fields regardless of which constructor was used.
        /// </summary>
        /// <param name="apiKey">Your SendGrid API key.</param>
        /// <param name="host">Base url (e.g. https://api.sendgrid.com)</param>
        /// <param name="requestHeaders">A dictionary of request headers</param>
        /// <param name="version">API version, override AddVersion to customize</param>
        /// <param name="urlPath">Path to endpoint (e.g. /path/to/endpoint)</param>
        private void InitiateClient(string apiKey, string host, Dictionary<string, string> requestHeaders, string version, string urlPath)
        {
            UrlPath = urlPath;
            Version = version;

            var baseAddress = host ?? "https://api.assurbox.net";
            var clientVersion = GetType().GetTypeInfo().Assembly.GetName().Version.ToString();

            // standard headers
            client.BaseAddress = new Uri(baseAddress);
            Dictionary<string, string> headers = new Dictionary<string, string>
            {
               // { "Authorization", "Bearer " + apiKey },
                { "Content-Type", "application/json" },
                { "User-Agent", "assurbox/" + clientVersion + " csharp" },
                { "Accept", "application/json" }
            };

            if (string.IsNullOrWhiteSpace(apiKey) == false)
            {
                headers.Add("Authorization", "Bearer " + apiKey);
            }

            // set header overrides
            if (requestHeaders != null)
            {
                foreach (var header in requestHeaders)
                {
                    headers[header.Key] = header.Value;
                }
            }

            // add headers to httpClient
            foreach (var header in headers)
            {
                if (header.Key == "Authorization")
                {
                    var split = header.Value.Split();
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(split[0], split[1]);
                }
                else if (header.Key == "Content-Type")
                {
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(header.Value));
                    MediaType = header.Value;
                }
                else
                {
                    client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }
            }
        }

        public void Dispose()
        {
            if (client != null)
            {
                client.Dispose();
            }
        }
    }
}
