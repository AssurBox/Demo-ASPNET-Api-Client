﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.EndpointContracts.Insurers
{

    public enum CommunicationType
    {
        InitialRequest = 0,
        Modification = 1,
        Cancelation = 2
    }

    public class ApiContract
    {
        /// <summary>
        /// Reference key for communication between AssurBox and other APIs
        /// This represents the whole file (ex : the whole green card request)
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Reference key for communication between AssurBox and other APIs
        /// This represents a specific message (useful if several requests are made for the same green card > modifications)
        /// </summary>
        public Guid MessageId { get; set; }

        /// <summary>
        /// Type of communication
        /// </summary>
        public CommunicationType CommunicationType { get; set; }

        /// <summary>
        /// Number of attempt to send data
        /// </summary>
        public int AttemptCount { get; set; }

    }
}
