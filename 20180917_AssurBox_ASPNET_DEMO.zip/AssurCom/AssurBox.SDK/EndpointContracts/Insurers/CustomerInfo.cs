﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.EndpointContracts.Insurers
{
    /// <summary>
    /// This class is what AssurBox expects if sending a get request on an insurer endpoint to retrieve customer information
    /// </summary>
    /// <remarks>Not specific to the green card request</remarks>
    public class CustomerInfo
    {
        /// <summary>
        /// Reference in the insurer system
        /// </summary>
        public string Reference { get; set; }
        /// <summary>
        /// First name
        /// </summary>
        /// <example>
        /// Bertrand
        /// </example>
        public string FirstName { get; set; }
        /// <summary>
        /// Last Name
        /// </summary>
        /// <example>
        /// Deroanne
        /// </example>
        public string LastName { get; set; }
        /// <summary>
        /// Address
        /// </summary>
        /// <example>
        /// 81 Rue des Mérovingiens L-8070 Bertrange
        /// </example>
        public string Address { get; set; }
        /// <summary>
        /// Birthday of the customer
        /// </summary>
        public DateTime? BirthDate { get; set; }
    }
}
