﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    /// <summary>
    /// Base class for api response
    /// </summary>
    public class ApiResponse : ApiMessage
    {
        /// <summary>
        /// Content
        /// </summary>
        public string ResponseContent { get; set; }
    }
}
