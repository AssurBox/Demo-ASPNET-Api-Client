﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// Reprensents a company
    /// </summary>
    /// <remarks>
    /// A company is not an user of AssurBox, it can be a customer for a green card request
    /// </remarks>
    public class Company
    {
        /// <summary>
        /// Name of the company
        /// </summary>
        /// <example>
        /// C-Services SA
        /// </example>
        public string Name { get; set; }

        /// <summary>
        /// VAT of the company (international vat number)
        /// </summary>
        /// <example>
        /// LU22548649
        /// </example>
        public string VAT { get; set; }

        /// <summary>
        /// Address of the company headquarters
        /// </summary>
        /// <example>
        /// 89A Parc d'Activités Capellen
        /// rue Pafebruch
        /// L-8308 Capellen
        /// Luxembourg
        /// </example>
        public Address LegalAddress { get; set; }

        /// <summary>
        /// The person representative for the company
        /// </summary>
        public Person Representative { get; set; }
    }
}
