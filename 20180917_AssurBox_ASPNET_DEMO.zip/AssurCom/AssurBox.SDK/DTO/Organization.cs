﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// An organization is a company that uses AssurBox 
    /// </summary>
    public class Organization
    {
        /// <summary>
        /// Identifier of the organization in AssurBox
        /// </summary>
        public int? Identifier { get; set; }

        /// <summary>
        /// VAT number  (International VAT number)
        /// </summary>
        /// <example>
        /// LU19536005
        /// </example>
        public string VAT { get; set; }

        /// <summary>
        /// Name of the organization
        /// </summary>
        /// <example>
        /// Autopolis SA
        /// </example>
        public string Name { get; set; }
    }
}
