﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// Types of fuel
    /// </summary>
    public enum FuelTypes : int
    {
        /// <summary>
        /// Undefined
        /// </summary>
        Undefined = 0,
        /// <summary>
        /// Bi-carburation Essence - BioEthanol
        /// </summary>
        BicarburationEssenceBioethanol = 2,
        /// <summary>
        /// Bi-carburation Essence - GNV
        /// </summary>
        BicarburationEssence_GNV = 3,
        /// <summary>
        /// Bi-carburation Essence - GPL
        /// </summary>
        BicarburationEssence_gpl = 4,
        /// <summary>
        /// Biocarburants
        /// </summary>
        Biocarburant = 5,
        /// <summary>
        /// Diesel
        /// </summary>
        Diesel = 6,
        /// <summary>
        /// Electric
        /// </summary>
        Electrique = 7,
        /// <summary>
        /// Essence
        /// </summary>
        Essence = 8,
        /// <summary>
        /// Hybride Diesel - Electric
        /// </summary>
        HybrideDieselElectrique = 9,
        /// <summary>
        /// Hybrid Essence - Electric
        /// </summary>
        HybrideEssenceElectrique = 10,
        /// <summary>
        /// Unknown (not cumunicated)
        /// </summary>
        NC = 11,
    }
}
