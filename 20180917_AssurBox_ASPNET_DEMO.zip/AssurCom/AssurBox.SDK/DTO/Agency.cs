﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// An agency is part of an organization (it can be an agent for an insurer)
    /// </summary>
    public class Agency : Organization
    {
        /// <summary>
        /// Agency specific reference at the organization (internal identifier of an agent)
        /// </summary>
        public string Reference { get; set; }
    }
}
