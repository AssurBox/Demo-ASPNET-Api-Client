﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssurBox.SDK.Clients
{
    public class OrganizationClient : AssurBoxClient
    {
        public OrganizationClient(AssurBoxClientOptions options) : base(options)
        {
        }

        public OrganizationClient(HttpClient httpClient, AssurBoxClientOptions options) : base(httpClient, options)
        {
        }

        public OrganizationClient(string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public OrganizationClient(HttpClient httpClient, string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(httpClient, apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public async Task<IEnumerable<DTO.Organization>> GetInsurances( CancellationToken cancellationToken = default(CancellationToken))
        {

            var response = await client.GetAsync($"/api/{Version}/Organizations/Insurances");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<IEnumerable<DTO.Organization>>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<IEnumerable<DTO.Agency>> GetInsuranceAgencies(string insuranceVAT, CancellationToken cancellationToken = default(CancellationToken))
        {

            var response = await client.GetAsync($"/api/{Version}/Organizations/Insurances/{insuranceVAT}/Agencies");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<IEnumerable<DTO.Agency>>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<IEnumerable<DTO.Organization>> GetDealers(CancellationToken cancellationToken = default(CancellationToken))
        {

            var response = await client.GetAsync($"/api/{Version}/Organizations/Dealers");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<IEnumerable<DTO.Organization>>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }
    }
}
