﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    // todo: implement
    /// <summary>
    /// Links for <see href="https://en.wikipedia.org/wiki/HATEOAS">HATEOAS</see>
    /// </summary>
    public class Link
    {
        /// <summary>
        /// 
        /// </summary>
        public string Href { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Rel { get; set; }
        /// <summary>
        /// Type of method
        /// </summary>
        /// <example>
        /// POST
        /// GET
        /// PUT
        /// DELETE
        /// </example>
        public string Method { get; set; }
    }
}
