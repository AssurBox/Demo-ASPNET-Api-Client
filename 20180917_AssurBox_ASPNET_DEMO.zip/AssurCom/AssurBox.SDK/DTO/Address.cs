﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// Represents an Address for AssurBox API
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Street
        /// </summary>
        /// <example>
        /// Val Sainte Croix
        /// </example>
        public string Street { get; set; }
        /// <summary>
        /// Street number
        /// </summary>
        /// <example>
        /// 99
        /// </example>
        public string Number { get; set; }
        /// <summary>
        /// Post box number
        /// </summary>
        /// <example>
        /// bte 15
        /// </example>
        public string PostboxNumber { get; set; }
        /// <summary>
        /// Zip code
        /// </summary>
        /// <example>
        /// 1371
        /// </example>
        public string ZipOrPostcode { get; set; }
        /// <summary>
        /// City
        /// </summary>
        /// <example>
        /// Luxembourg
        /// </example>
        public string City { get; set; }
        /// <summary>
        /// Country
        /// </summary>
        /// <example>
        /// "Luxembourg" or "LU"
        /// </example>
        public string Country { get; set; }
        /// <summary>
        /// State, or province, according to the country
        /// </summary>
        public string StateOrProvince { get; set; }
        /// <summary>
        /// Some complements
        /// </summary>
        /// <example>
        /// Appartement 3B
        /// </example>
        public string OtherAddressDetails { get; set; }
    }
}
