﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO.GreenCard.Car
{
    /// <summary>
    /// Reprents a request made to an insurer for a green card (for a car)
    /// </summary>
    public class GreenCardRequestInitialization : ApiMessage
    {
        /// <summary>
        /// Date of request creation
        /// </summary>
        public DateTime RequestDateUTC { get; set; }

        /// <summary>
        /// Insurance to whom the request is made.
        /// </summary>
        public Organization RecipientInsurer { get; set; }

        /// <summary>
        /// Details of the car
        /// </summary>
        public Car CarDetails { get; set; }

        /// <summary>
        /// Customer for the card request
        /// </summary>
        public Customer Customer { get; set; }

        /// <summary>
        /// Information about the driver of the car
        /// </summary>
        public Person Driver { get; set; }

        /// <summary>
        /// Information about the owner of the vehicle.
        /// In the case of a leasing, it should be the leasing information
        /// </summary>
        public Company OwnerIfDifferentFromCustomer { get; set; }

        /// <summary>
        /// A commmunication for the insurer 
        /// </summary>
        public string Communication { get; set; }

        /// <summary>
        /// Date on which the green card should be effective
        /// </summary>
        public DateTime EffectiveDate { get; set; }

        /// <summary>
        /// In the case of a <see cref="">Transcription </see> or a <see cref="">Transfert</see>
        /// </summary>
        public string LicencePlateToReplace { get; set; }
        /// <summary>
        /// In the case of a <see cref="">Transfert</see>
        /// </summary>
        public Organization TransfertInsurer { get; set; }
    }
}
