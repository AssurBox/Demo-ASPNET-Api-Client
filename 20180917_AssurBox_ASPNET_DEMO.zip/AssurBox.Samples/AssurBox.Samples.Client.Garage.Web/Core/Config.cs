﻿

namespace AssurBox.Samples.Client.Garage.Web.Core
{
    public static class Config
    {
      

        public static string Host
        {
            get
            {
                return "https://devslot.assurbox.net";
            }
        }
    }
}