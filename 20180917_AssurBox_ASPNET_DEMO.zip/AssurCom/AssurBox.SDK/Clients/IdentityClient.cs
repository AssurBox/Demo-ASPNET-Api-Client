﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AssurBox.SDK.Clients
{
    public class IdentityClient : AssurBoxClient
    {
        public IdentityClient(AssurBoxClientOptions options) : base(options)
        {
        }

        public IdentityClient(HttpClient httpClient, AssurBoxClientOptions options) : base(httpClient, options)
        {
        }

        public IdentityClient(string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public IdentityClient(HttpClient httpClient, string apiKey, string host = null, Dictionary<string, string> requestHeaders = null, string version = "v1", string urlPath = null) : base(httpClient, apiKey, host, requestHeaders, version, urlPath)
        {
        }

        public async Task<JwtTokenResult> GetBearerToken(string clientId, string clientSecret, CancellationToken cancellationToken = default(CancellationToken))
        {
            //var response = await client.PostAsJsonAsync($"/oauth/token", new
            //{
            //    grant_type = "client_credentials",
            //    client_id = clientId,
            //    client_secret = clientSecret
            //});

            var parameters = new Dictionary<string, string>
           {
               {"grant_type", "client_credentials"},
               {"client_id", clientId},
               {"client_secret", clientSecret},
           };
            var response = await client.PostAsync("/oauth/token", new FormUrlEncodedContent(parameters));

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<JwtTokenResult>();
            }
            else
            {
                var error = response.Content.ReadAsStringAsync().Result;
                throw new AssurBoxException((int)response.StatusCode, response.ReasonPhrase + " ---- " + error);
            }
        }

        public async Task<string> GetCurrentUserName(CancellationToken cancellationToken = default(CancellationToken))
        {

            var response = await client.GetAsync($"/api/{Version}/users/whoami");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<string>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

        public async Task<string> GetCurrentUserOrganization(CancellationToken cancellationToken = default(CancellationToken))
        {
            var response = await client.GetAsync($"/api/{Version}/users/whatorganization");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsAsync<string>();
            }
            else
            {
                var error = response.Content.ReadAsApiErrorAsync().Result;
                throw new AssurBoxException(error, (int)response.StatusCode, response.ReasonPhrase);
            }
        }

    }
}
