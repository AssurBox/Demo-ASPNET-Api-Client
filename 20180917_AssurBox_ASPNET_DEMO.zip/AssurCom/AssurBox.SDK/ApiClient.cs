﻿//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Linq;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Text;
//using System.Threading.Tasks;

//namespace AssurBox.SDK
//{
//    //https://stackoverflow.com/questions/14627399/setting-authorization-header-of-httpclient
//    public class ApiClient : IDisposable
//    {
//        private string ApiKey { get; set; }

//        public ApiClient()
//        {
//            this.ApiKey = ConfigurationManager.AppSettings["AssurBox:Api:Key"];
//            Client = new HttpClient();
//            var baseaddress = ConfigurationManager.AppSettings["AssurBox:Api:UrlRoot"] ?? "http://localhost";
//            Client.BaseAddress = new Uri(baseaddress);
//            Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

//            if (string.IsNullOrEmpty(this.ApiKey) == false)
//            {
//                string authenticationScheme = ConfigurationManager.AppSettings["AssurBox:Api:Scheme"] ?? "Basic";
//                Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authenticationScheme, this.ApiKey);
//            }
//            // pas ca ici: ca écrase tout le reste ... -> c'est soit dans fichier config, soit sur une surcharge du client
//            //    var credentials = Encoding.ASCII.GetBytes("Garage Isidore:AssurBox*123");
//            //   Client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(credentials));
//        }

//        public ApiClient(Uri baseAddress) : this()
//        {
//            Client.BaseAddress = baseAddress;
//        }

//        public ApiClient(string baseAddress) : this(new Uri(baseAddress))
//        {
//        }
//        public ApiClient(string baseAddress, string key) : this(new Uri(baseAddress), key)
//        {
//        }
//        public ApiClient(Uri baseAddress, string key) : this(baseAddress)
//        {
//            this.ApiKey = key;
//            if (string.IsNullOrEmpty(this.ApiKey))
//            {
//                Client.DefaultRequestHeaders.Authorization = null;
//            }
//            else
//            {
//                Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", this.ApiKey);
//            }
//        }

//        public ApiClient(string apiRootUrl, string apiKey, string apiScheme) : this(apiRootUrl)
//        {
//            this.ApiKey = apiKey;
//            if (string.IsNullOrEmpty(this.ApiKey))
//            {
//                Client.DefaultRequestHeaders.Authorization = null;
//            }
//            else
//            {
//                Client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(apiScheme ?? "Basic", this.ApiKey);
//            }
//        }

//        public HttpClient Client { get; set; }

//        public void SetBasicAuthentication(string username, string password)
//        {
//            var credentials = Encoding.ASCII.GetBytes($"{username}:{password}");
//            SetBasicAuthentication(Convert.ToBase64String(credentials));
//        }
//        public void SetBasicAuthentication(string basee64encodedusernamepassword)
//        {
//            Client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", basee64encodedusernamepassword);
//        }

//        public void SetBearerToken(string token)
//        {
//            Client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
//        }

//        /// <summary>
//        /// Test if AssurBox is answering
//        /// </summary>
//        /// <param name="echoMessage"></param>
//        /// <returns></returns>
//        public string Echo(string echoMessage)
//        {
//            try
//            {
//                HttpResponseMessage response = Client.GetAsync($"Api/Echo/{echoMessage}").Result;
//                if (response.IsSuccessStatusCode)
//                {
//                    var message = response.Content.ReadAsAsync<string>().Result;
//                    return message;
//                }
//                return $"AssurBox::Error:{response.ReasonPhrase}";
//            }
//            catch (Exception ex)
//            {
//                return $"AssurBox::Error:{ex.GetBaseException().Message}";
//            }
//        }

 

//        public void Dispose()
//        {
//            if (Client != null)
//            {
//                Client.Dispose();
//            }
//        }

    

//    }
//}
