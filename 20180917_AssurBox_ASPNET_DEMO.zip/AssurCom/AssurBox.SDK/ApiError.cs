﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK
{
    /// <summary>
    ///  ApiError from Microsoft API guidelines
    ///  <see href="https://github.com/Microsoft/api-guidelines/blob/master/Guidelines.md#710-response-formats"/>
    /// </summary>
    public class ApiError
    {
        /// <summary>
        /// 
        /// </summary>
        public ApiError()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorCode"></param>
        /// <param name="message"></param>
        public ApiError(string errorCode, string message)
        {
            this.Error = new Error
            {
                Code = errorCode,
                Message = message
            };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorCode"></param>
        /// <param name="message"></param>
        /// <param name="target"></param>
        public ApiError(string errorCode, string message, string target) : this(errorCode, message)
        {
            this.Error.Target = target;
        }
        /// <summary>
        /// 
        /// </summary>
        public Error Error { get; set; }

        public override string ToString()
        {
            if (this.Error != null)
            {
                string errormessage = $@"Error detail : 
{this.Error.Code} - {this.Error.Message}
";
                foreach (var er in this.Error.Details)
                {
                    errormessage += $@"
--------------
{er.Code} : {er.Message}
";
                }

                return errormessage;
            }

            return base.ToString();
        }
    }
    /// <summary>
    /// ApiError from Microsoft API guidelines
    /// </summary>
    public class Error
    {
        /// <summary>
        /// Error code 
        /// </summary>
        /// <example>
        /// 500
        /// </example>
        public string Code { get; set; }
        /// <summary>
        /// Error message
        /// </summary>
        /// <example>
        /// Internal server error
        /// </example>
        public string Message { get; set; }
        /// <summary>
        /// Error target
        /// </summary>
        public string Target { get; set; }
        /// <summary>
        /// Detail 
        /// </summary>
        public Error[] Details { get; set; }

        /// <summary>
        /// Inner error (more details)
        /// </summary>
        /// <remarks>
        /// Can be on many levels
        /// </remarks>
        public InnerError InnerError { get; set; }

        /// <summary>
        /// Utility method to add details to the error
        /// </summary>
        /// <param name="code"></param>
        /// <param name="message"></param>
        /// <param name="target"></param>
        public void AddDetails(string code, string message, string target = "")
        {
            if (this.Details == null)
            {
                this.Details = new List<Error>().ToArray();
            }
            this.Details = new List<Error>(this.Details) { new Error { Code = code, Message = message, Target = target } }.ToArray();
        }
        /// <summary>
        /// Utility method to add details to the error
        /// </summary>
        /// <param name="errors"></param>
        public void AddDetails(IEnumerable<string> errors)
        {
            foreach (var error in errors)
            {
                this.AddDetails("ErrorCode", error);
            }
        }
    }
    /// <summary>
    /// Inner errror information
    /// </summary>
    public class InnerError
    {
        /// <summary>
        /// Error code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Inner error 
        /// </summary>
        public InnerError innerError { get; set; }
    }
}
