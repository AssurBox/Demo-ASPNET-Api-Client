﻿using AssurBox.SDK.DTO;
using AssurBox.SDK.DTO.GreenCard.Car;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.EndpointContracts.Insurers
{
    /// <summary>
    /// Represents a green card request
    /// </summary>
    public class GreenCardRequestContract : ApiContract
    {
        /// <summary>
        /// Requester of the green card
        /// </summary>
        public Organization Requester { get; set; }

        /// <summary>
        /// Details of the car
        /// </summary>
        public Car CarDetails { get; set; }

        /// <summary>
        /// Customer for the card request
        /// </summary>
        public Customer Customer { get; set; }

        /// <summary>
        /// Information about the driver of the car
        /// </summary>
        public Person Driver { get; set; }

        /// <summary>
        /// Information about the owner of the vehicle.
        /// In the case of a leasing, it should be the leasing information
        /// </summary>
        public Company OwnerIfDifferentFromCustomer { get; set; }

        /// <summary>
        /// A commmunication for the insurer 
        /// </summary>
        public string Communication { get; set; }

        /// <summary>
        /// Date on which the green card should be effective
        /// </summary>
        public DateTime EffectiveDate { get; set; }

        /// <summary>
        /// In the case of a Transcription or a Transfert
        /// </summary>
        /// <remarks>
        /// Transcription : when the new car replace a car on an existing contract
        /// Transfert : when the new car replace a car on an existing contract at an other insurer
        /// </remarks>
        public string LicencePlateToReplace { get; set; }
        /// <summary>
        /// In the case of a Transfert
        /// </summary>
        /// <remarks>
        /// Transfert : when the new car replace a car on an existing contract at an other insurer
        /// </remarks>
        public Organization TransfertInsurer { get; set; }
    }


}
