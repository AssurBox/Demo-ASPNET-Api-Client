﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO
{
    /// <summary>
    /// Reprensents a vehicle
    /// </summary>
    public class Vehicle
    {
        /// <summary>
        /// The licence plate
        /// </summary>
        /// <remarks>Mandatory</remarks>
        public string LicencePlate { get; set; }
        /// <summary>
        /// The Vehicle Identification Number
        /// </summary>
        /// <remarks>Mandatory</remarks>
        public string VIN { get; set; }


        /// <summary>
        /// If your organization uses Eurotax, you can use this field 
        /// </summary>
        public string EuroTaxID { get; set; }

        /// <summary>
        /// If it's an used vehicle
        /// </summary>
        public int UsedVehicleMileage { get; set; }
        
        /// <summary>
        /// Date of the registration of the vehicle
        /// </summary>
        public DateTime? DateOfVehicleRegistration { get; set; }

        /// <summary>
        /// Make of the vehicle
        /// </summary>
        /// <example>
        /// volkswagen
        /// </example>
        public string Make { get; set; }
        /// <summary>
        /// Model of the vehicle
        /// </summary>
        public string Model { get; set; }
        /// <summary>
        /// Model's version
        /// </summary>
        public string Version { get; set; }
        /// <summary>
        /// Price with option (VAT included)
        /// </summary>
        public string PriceWithOption { get; set; }
        /// <summary>
        /// Price without option (VAT included)
        /// </summary>
        public string PriceWithoutOption { get; set; }
        /// <summary>
        /// Engine size (cm³)
        /// </summary>
        public int EngineSizeInCm3 { get; set; }
        /// <summary>
        /// Engine power (kw)
        /// </summary>
        public double EnginePowerInKw { get; set; }
        /// <summary>
        /// Engine power (ch)
        /// </summary>
        public int EnginePowerInCH { get; set; }
        /// <summary>
        /// Fuel type
        /// </summary>
        public FuelTypes Fuel { get; set; }
        /// <summary>
        /// Weight (kg) - unloaded
        /// </summary>
        public int? UnloadedWeightInKg { get; set; }
    }
}
