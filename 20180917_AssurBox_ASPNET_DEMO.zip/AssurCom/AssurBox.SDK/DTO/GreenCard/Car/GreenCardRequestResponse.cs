﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssurBox.SDK.DTO.GreenCard.Car
{
    /// <summary>
    /// Contract to be POSTED to the AssurBox's response endpoint for a green card request
    /// </summary>
    public class GreenCardRequestResponse : ApiResponse
    {
        public GreenCardRequestResponse()
        {
            this.Attachments = new List<Attachment>();
        }

        /// <summary>
        /// The unique identifier for the whole process of the green card request
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// The unique identifier for the current request message
        /// </summary>
        public Guid MessageID { get; set; }

        ///// <summary>
        ///// Si pour une version spécifique
        ///// </summary>
        //public string AssurBoxMessageVersion { get; set; }

        /// <summary>
        /// The green card file and additional files if needed
        /// </summary>
        public List<Attachment> Attachments { get; set; }

        /// <summary>
        /// Some information if wanted
        /// </summary>
        public string Communication { get; set; }

        /// <summary>
        /// Indicates if the green card request was approved
        /// </summary>
        public bool HasApproval { get; set; }

        /// <summary>
        /// Reason if no approval for the request
        /// </summary>
        public string ApprovalReason { get; set; }



        /// <summary>
        /// Append a file to the list of attachments
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="content">base 64</param>
        public void AddAttachment(string filename, string content, string type = "")
        {
            this.Attachments.Add(new Attachment { Filename = filename, Content = content, Type = type });
        }

    }
}
